#!/bin/bash

# Start the Streamlit application
echo "Starting Financial File Processor application..."
echo "Press Ctrl+C to stop the application when finished."
cd /home/ubuntu/financial_app
streamlit run app.py
